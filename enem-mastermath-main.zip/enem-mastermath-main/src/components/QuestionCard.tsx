import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Lightbulb, Loader2 } from "lucide-react";
import type { GeneratedQuestion } from "@/hooks/useGenerateQuestion";

interface QuestionCardProps {
  question: GeneratedQuestion;
  onAnswer: (isCorrect: boolean, selectedAnswer: string) => void;
  onNext: () => void;
  showNextButton?: boolean;
  isLoadingNext?: boolean;
}

export function QuestionCard({
  question,
  onAnswer,
  onNext,
  showNextButton = true,
  isLoadingNext = false,
}: QuestionCardProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  const isCorrect = selectedAnswer === question.correctAnswer;

  const handleSelectAnswer = (answerId: string) => {
    if (!showResult) {
      setSelectedAnswer(answerId);
    }
  };

  const handleConfirmAnswer = () => {
    if (!selectedAnswer) return;
    setShowResult(true);
    onAnswer(selectedAnswer === question.correctAnswer, selectedAnswer);
  };

  const handleNext = () => {
    setSelectedAnswer(null);
    setShowResult(false);
    setShowExplanation(false);
    onNext();
  };

  return (
    <div className="rounded-2xl bg-card p-8 shadow-medium">
      {/* Statement */}
      <div className="mb-8">
        <p className="text-lg leading-relaxed text-foreground">{question.statement}</p>
      </div>

      {/* Options */}
      <div className="mb-8 space-y-3">
        {question.options.map((option) => {
          const isSelected = selectedAnswer === option.id;
          const isCorrectOption = option.id === question.correctAnswer;

          let optionClass =
            "flex cursor-pointer items-center gap-4 rounded-xl border-2 p-4 transition-all";

          if (showResult) {
            if (isCorrectOption) {
              optionClass += " border-success bg-success/10";
            } else if (isSelected && !isCorrectOption) {
              optionClass += " border-destructive bg-destructive/10";
            } else {
              optionClass += " border-border opacity-50";
            }
          } else if (isSelected) {
            optionClass += " border-primary bg-primary/5";
          } else {
            optionClass += " border-border hover:border-primary/50 hover:bg-muted/50";
          }

          return (
            <div
              key={option.id}
              className={optionClass}
              onClick={() => handleSelectAnswer(option.id)}
            >
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-lg font-semibold ${
                  isSelected
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {option.id.toUpperCase()}
              </div>
              <span className="flex-1 text-foreground">{option.text}</span>
              {showResult && isCorrectOption && (
                <CheckCircle className="h-5 w-5 text-success" />
              )}
              {showResult && isSelected && !isCorrectOption && (
                <XCircle className="h-5 w-5 text-destructive" />
              )}
            </div>
          );
        })}
      </div>

      {/* Actions */}
      {!showResult ? (
        <Button
          onClick={handleConfirmAnswer}
          disabled={!selectedAnswer}
          className="w-full"
          size="lg"
        >
          Confirmar Resposta
        </Button>
      ) : (
        <div className="space-y-4">
          {/* Result Banner */}
          <div
            className={`rounded-xl p-4 text-center ${
              isCorrect
                ? "bg-success/10 text-success"
                : "bg-destructive/10 text-destructive"
            }`}
          >
            <div className="flex items-center justify-center gap-2 text-lg font-semibold">
              {isCorrect ? (
                <>
                  <CheckCircle className="h-5 w-5" />
                  Resposta Correta!
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5" />
                  Resposta Incorreta
                </>
              )}
            </div>
          </div>

          {/* Explanation Toggle */}
          {!showExplanation ? (
            <Button
              variant="outline"
              className="w-full gap-2"
              onClick={() => setShowExplanation(true)}
            >
              <Lightbulb className="h-4 w-4" />
              Ver Explicação
            </Button>
          ) : (
            <div className="rounded-xl bg-muted/50 p-6">
              <div className="mb-3 flex items-center gap-2 text-sm font-medium text-foreground">
                <Lightbulb className="h-4 w-4 text-accent" />
                Resolução
              </div>
              <pre className="whitespace-pre-wrap font-sans text-sm text-muted-foreground">
                {question.explanation}
              </pre>
            </div>
          )}

          {/* Next Question */}
          {showNextButton && (
            <Button
              onClick={handleNext}
              className="w-full gap-2"
              size="lg"
              disabled={isLoadingNext}
            >
              {isLoadingNext ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Gerando próxima questão...
                </>
              ) : (
                "Próxima Questão"
              )}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

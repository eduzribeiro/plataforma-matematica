import { ReactNode } from "react";
import { Lock, Crown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

interface TopicCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  percentage: number;
  questionsCount: number;
  isPremium?: boolean;
  isLocked?: boolean;
  href: string;
  colorClass?: string;
}

export function TopicCard({
  title,
  description,
  icon,
  percentage,
  questionsCount,
  isPremium = false,
  isLocked = false,
  href,
  colorClass = "bg-primary",
}: TopicCardProps) {
  const { isPremium: userIsPremium } = useAuth();
  
  // User can access if: not premium content, OR user has premium subscription
  const canAccess = !isPremium || userIsPremium;
  const showLocked = isLocked && !userIsPremium;

  return (
    <div className="topic-card group relative">
      {/* Premium Badge */}
      {isPremium && (
        <div className="absolute right-4 top-4 z-10">
          <span className="premium-badge">
            <Crown className="h-3 w-3" />
            Premium
          </span>
        </div>
      )}

      {/* Icon */}
      <div
        className={cn(
          "mb-4 flex h-14 w-14 items-center justify-center rounded-xl text-white transition-transform group-hover:scale-110",
          colorClass
        )}
      >
        {icon}
      </div>

      {/* Content */}
      <h3 className="mb-2 font-display text-lg font-semibold text-foreground">
        {title}
      </h3>
      <p className="mb-4 text-sm text-muted-foreground line-clamp-2">
        {description}
      </p>

      {/* Stats */}
      <div className="mb-4 flex items-center gap-4 text-xs">
        <div className="flex items-center gap-1.5">
          <div className="h-2 w-2 rounded-full bg-accent" />
          <span className="font-medium text-foreground">{percentage}%</span>
          <span className="text-muted-foreground">no ENEM</span>
        </div>
        <div className="text-muted-foreground">
          {questionsCount} questões
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all"
          style={{ width: "0%" }}
        />
      </div>

      {/* Action */}
      {showLocked ? (
        <Button variant="secondary" className="w-full gap-2" disabled>
          <Lock className="h-4 w-4" />
          Desbloquear
        </Button>
      ) : (
        <Button variant="outline" className="w-full" asChild>
          <Link to={href}>
            Acessar Conteúdo
          </Link>
        </Button>
      )}

      {/* Locked Overlay */}
      {showLocked && (
        <div className="locked-overlay">
          <Link to="/assinatura">
            <Button className="gap-2 shadow-lg">
              <Crown className="h-4 w-4" />
              Desbloquear com Premium
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}

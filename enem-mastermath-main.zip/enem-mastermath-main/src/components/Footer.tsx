import { Link } from "react-router-dom";
import { BookOpen, Mail, Instagram, Youtube } from "lucide-react";
export function Footer() {
  return <footer className="border-t border-border bg-muted/30">
      <div className="container py-12">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
                <span className="font-display text-lg font-bold text-primary-foreground">M</span>
              </div>
              <div>
                <p className="font-display text-sm font-bold leading-tight text-foreground">
                  Matemática Completa para o ENEM
                </p>
                <p className="text-xs text-muted-foreground">Professor Eduardo Ribeiro</p>
              </div>
            </div>
            <p className="mt-4 max-w-md text-sm text-muted-foreground">
              A plataforma mais completa de preparação em matemática para o ENEM. 
              Teoria, exercícios, simulados e muito mais para você alcançar a nota dos seus sonhos.
            </p>
            <div className="mt-4 flex gap-3">
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground">
                <Youtube className="h-4 w-4" />
              </a>
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground">
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="mb-4 font-display font-semibold text-foreground">Plataforma</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/temas" className="text-muted-foreground hover:text-foreground">
                  Temas de Matemática
                </Link>
              </li>
              <li>
                <Link to="/exercicios" className="text-muted-foreground hover:text-foreground">
                  Exercícios
                </Link>
              </li>
              <li>
                <Link to="/desafios" className="text-muted-foreground hover:text-foreground">
                  Desafios
                </Link>
              </li>
              <li>
                <Link to="/progresso" className="text-muted-foreground hover:text-foreground">
                  Meu Progresso
                </Link>
              </li>
            </ul>
          </div>

          <div>
            
            <ul className="space-y-2 text-sm">
              <li>
                
              </li>
              <li>
                
              </li>
              <li>
                
              </li>
              <li>
                
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-6">
          <p className="text-center text-xs text-muted-foreground">
            © {new Date().getFullYear()} Matemática Completa para o ENEM - Prof. Eduardo Ribeiro. 
            Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>;
}
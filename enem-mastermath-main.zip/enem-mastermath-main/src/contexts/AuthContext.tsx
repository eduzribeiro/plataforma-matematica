import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

interface SubscriptionInfo {
  subscribed: boolean;
  subscriptionEnd: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  subscription: SubscriptionInfo;
  isPremium: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  refreshSubscription: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState<SubscriptionInfo>({
    subscribed: false,
    subscriptionEnd: null,
  });

  // Ensure user records exist in profiles, user_stats, and subscriptions
  const ensureUserRecords = useCallback(async (userId: string, userEmail: string, fullName?: string) => {
    try {
      // Check and create profile if missing
      const { data: existingProfile } = await supabase
        .from("profiles")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (!existingProfile) {
        const displayName = fullName || userEmail.split("@")[0];
        await supabase.from("profiles").insert({
          user_id: userId,
          display_name: displayName,
        });
      }

      // Check and create user_stats if missing
      const { data: existingStats } = await supabase
        .from("user_stats")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (!existingStats) {
        await supabase.from("user_stats").insert({
          user_id: userId,
        });
      }

      // Check and create subscription if missing
      const { data: existingSubscription } = await supabase
        .from("subscriptions")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (!existingSubscription) {
        await supabase.from("subscriptions").insert({
          user_id: userId,
          is_premium: false,
        });
      }
    } catch (err) {
      console.error("Error ensuring user records:", err);
    }
  }, []);

  const checkSubscription = useCallback(async () => {
    if (!session?.user) {
      setSubscription({ subscribed: false, subscriptionEnd: null });
      return;
    }

    try {
      const { data, error } = await supabase
        .from("subscriptions")
        .select("is_premium, premium_until")
        .eq("user_id", session.user.id)
        .maybeSingle();
      
      if (error) {
        console.error("Error checking subscription:", error);
        return;
      }

      setSubscription({
        subscribed: data?.is_premium || false,
        subscriptionEnd: data?.premium_until || null,
      });
    } catch (err) {
      console.error("Failed to check subscription:", err);
    }
  }, [session]);

  const refreshSubscription = useCallback(async () => {
    await checkSubscription();
  }, [checkSubscription]);

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription: authSubscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        // Only synchronous state updates here - NEVER use async directly
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);

        // Defer Supabase calls with setTimeout to prevent deadlocks
        if (session?.user && (event === "SIGNED_IN" || event === "TOKEN_REFRESHED")) {
          setTimeout(() => {
            const fullName = session.user.user_metadata?.full_name;
            ensureUserRecords(session.user.id, session.user.email || "", fullName);
          }, 0);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);

      // Defer Supabase calls with setTimeout
      if (session?.user) {
        setTimeout(() => {
          const fullName = session.user.user_metadata?.full_name;
          ensureUserRecords(session.user.id, session.user.email || "", fullName);
        }, 0);
      }
    });

    return () => authSubscription.unsubscribe();
  }, [ensureUserRecords]);

  // Check subscription when session changes
  useEffect(() => {
    if (session) {
      // Defer the subscription check
      setTimeout(() => {
        checkSubscription();
      }, 100);
    } else {
      setSubscription({ subscribed: false, subscriptionEnd: null });
    }
  }, [session, checkSubscription]);

  // Auto-refresh subscription every minute
  useEffect(() => {
    if (!session) return;

    const interval = setInterval(() => {
      checkSubscription();
    }, 60000);

    return () => clearInterval(interval);
  }, [session, checkSubscription]);

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      return { error: error ? new Error(error.message) : null };
    } catch (err) {
      return { error: err instanceof Error ? err : new Error("Erro ao fazer login") };
    }
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: { full_name: fullName },
        },
      });
      return { error: error ? new Error(error.message) : null };
    } catch (err) {
      return { error: err instanceof Error ? err : new Error("Erro ao criar conta") };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const isPremium = subscription.subscribed;

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        loading,
        subscription,
        isPremium,
        signIn,
        signUp,
        signOut,
        refreshSubscription,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface GeneratedQuestion {
  id: string;
  statement: string;
  options: { id: string; text: string }[];
  correctAnswer: string;
  explanation: string;
  topic: string;
  difficulty: string;
}

interface UseGenerateQuestionOptions {
  topic: string;
  difficulty?: "easy" | "medium" | "hard";
  context?: "exercicio" | "desafio" | "simulado";
}

export function useGenerateQuestion() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const generateQuestion = async ({
    topic,
    difficulty = "medium",
    context = "exercicio",
  }: UseGenerateQuestionOptions): Promise<GeneratedQuestion | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke("generate-question", {
        body: { topic, difficulty, context },
      });

      if (fnError) {
        throw new Error(fnError.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      return data as GeneratedQuestion;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erro ao gerar questão";
      setError(message);
      toast({
        variant: "destructive",
        title: "Erro ao gerar questão",
        description: message,
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return { generateQuestion, isLoading, error };
}

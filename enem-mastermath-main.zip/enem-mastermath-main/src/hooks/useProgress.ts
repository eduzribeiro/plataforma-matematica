import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface StudyProgress {
  id: string;
  user_id: string;
  topic_id: string;
  questions_answered: number;
  correct_answers: number;
  wrong_answers: number;
  time_spent_minutes: number;
}

export interface UserStats {
  id: string;
  user_id: string;
  total_study_days: number;
  total_study_hours: number;
  current_streak: number;
  longest_streak: number;
  last_study_date: string | null;
  xp_total: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  required_value: number;
  achievement_type: string;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_id: string;
  unlocked_at: string;
  achievements?: Achievement;
}

export function useStudyProgress() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["study-progress", user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("study_progress")
        .select("*")
        .eq("user_id", user.id);

      if (error) throw error;
      return data as StudyProgress[];
    },
    enabled: !!user,
  });
}

export function useUserStats() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["user-stats", user?.id],
    queryFn: async () => {
      if (!user) return null;

      const { data, error } = await supabase
        .from("user_stats")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      return data as UserStats | null;
    },
    enabled: !!user,
  });
}

export function useAchievements() {
  return useQuery({
    queryKey: ["achievements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("achievements")
        .select("*")
        .order("required_value", { ascending: true });

      if (error) throw error;
      return data as Achievement[];
    },
  });
}

export function useUserAchievements() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["user-achievements", user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .from("user_achievements")
        .select("*, achievements(*)")
        .eq("user_id", user.id);

      if (error) throw error;
      return data as UserAchievement[];
    },
    enabled: !!user,
  });
}

export function useRecordAnswer() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      topicId,
      questionId,
      isCorrect,
      timeTakenSeconds,
    }: {
      topicId: string;
      questionId: string;
      isCorrect: boolean;
      timeTakenSeconds: number;
    }) => {
      if (!user) throw new Error("User not authenticated");

      // Record question history
      const { error: historyError } = await supabase
        .from("question_history")
        .insert({
          user_id: user.id,
          topic_id: topicId,
          question_id: questionId,
          is_correct: isCorrect,
          time_taken_seconds: timeTakenSeconds,
        });

      if (historyError) throw historyError;

      // Upsert study progress
      const { data: existingProgress } = await supabase
        .from("study_progress")
        .select("*")
        .eq("user_id", user.id)
        .eq("topic_id", topicId)
        .maybeSingle();

      if (existingProgress) {
        const { error: updateError } = await supabase
          .from("study_progress")
          .update({
            questions_answered: existingProgress.questions_answered + 1,
            correct_answers: existingProgress.correct_answers + (isCorrect ? 1 : 0),
            wrong_answers: existingProgress.wrong_answers + (isCorrect ? 0 : 1),
            time_spent_minutes: existingProgress.time_spent_minutes + Math.ceil(timeTakenSeconds / 60),
          })
          .eq("id", existingProgress.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from("study_progress")
          .insert({
            user_id: user.id,
            topic_id: topicId,
            questions_answered: 1,
            correct_answers: isCorrect ? 1 : 0,
            wrong_answers: isCorrect ? 0 : 1,
            time_spent_minutes: Math.ceil(timeTakenSeconds / 60),
          });

        if (insertError) throw insertError;
      }

      // Update user stats
      const today = new Date().toISOString().split("T")[0];
      const xpGained = isCorrect ? 10 : 2;

      const { data: stats } = await supabase
        .from("user_stats")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (stats) {
        const isNewDay = stats.last_study_date !== today;
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split("T")[0];
        
        let newStreak = stats.current_streak;
        if (isNewDay) {
          if (stats.last_study_date === yesterdayStr) {
            newStreak = stats.current_streak + 1;
          } else if (stats.last_study_date !== today) {
            newStreak = 1;
          }
        }

        await supabase
          .from("user_stats")
          .update({
            total_study_days: isNewDay ? stats.total_study_days + 1 : stats.total_study_days,
            total_study_hours: Number(stats.total_study_hours) + (timeTakenSeconds / 3600),
            current_streak: newStreak,
            longest_streak: Math.max(stats.longest_streak, newStreak),
            last_study_date: today,
            xp_total: stats.xp_total + xpGained,
          })
          .eq("id", stats.id);
      }

      return { success: true, xpGained };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["study-progress"] });
      queryClient.invalidateQueries({ queryKey: ["user-stats"] });
      queryClient.invalidateQueries({ queryKey: ["user-achievements"] });
    },
  });
}

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ScrollToTop } from "@/components/ScrollToTop";
import Index from "./pages/Index";
import Temas from "./pages/Temas";
import Tema from "./pages/Tema";
import Exercicios from "./pages/Exercicios";
import Desafios from "./pages/Desafios";
import Progresso from "./pages/Progresso";
import Assinatura from "./pages/Assinatura";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/temas" element={<Temas />} />
            <Route path="/tema/:id" element={<Tema />} />
            <Route path="/exercicios" element={<Exercicios />} />
            <Route path="/desafios" element={<Desafios />} />
            <Route path="/progresso" element={<Progresso />} />
            <Route path="/assinatura" element={<Assinatura />} />
            <Route path="/login" element={<Login />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;

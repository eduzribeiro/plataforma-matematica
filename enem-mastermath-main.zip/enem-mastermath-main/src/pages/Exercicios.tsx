import { useState } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Target,
  ChevronRight,
  Lock,
  Crown,
  Loader2,
  Sparkles,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useGenerateQuestion, type GeneratedQuestion } from "@/hooks/useGenerateQuestion";
import { QuestionCard } from "@/components/QuestionCard";
import { useAuth } from "@/contexts/AuthContext";
import { useRecordAnswer } from "@/hooks/useProgress";

const topics = [
  { id: "geometria-plana", name: "Geometria Plana", isPremium: false },
  { id: "porcentagem", name: "Porcentagem e Juros", isPremium: false },
  { id: "estatistica", name: "Estatística", isPremium: false },
  { id: "funcoes", name: "Funções", isPremium: true },
  { id: "geometria-espacial", name: "Geometria Espacial", isPremium: true },
  { id: "probabilidade", name: "Probabilidade", isPremium: true },
  { id: "razao-proporcao", name: "Razão e Proporção", isPremium: true },
  { id: "algebra", name: "Álgebra", isPremium: true },
  { id: "progressoes", name: "Progressões", isPremium: true },
  { id: "trigonometria", name: "Trigonometria", isPremium: true },
];

const difficultyOptions = [
  { id: "easy", name: "Fácil" },
  { id: "medium", name: "Médio" },
  { id: "hard", name: "Difícil" },
];

export default function ExerciciosPage() {
  const { isPremium } = useAuth();
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [selectedDifficulty, setSelectedDifficulty] = useState<"easy" | "medium" | "hard">("medium");
  const [currentQuestion, setCurrentQuestion] = useState<GeneratedQuestion | null>(null);
  const [questionStarted, setQuestionStarted] = useState(false);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);

  const { generateQuestion, isLoading } = useGenerateQuestion();
  const recordAnswer = useRecordAnswer();

  const startExercise = async () => {
    const topic = topics.find((t) => t.id === selectedTopic);
    if (!topic) return;
    
    if (topic.isPremium && !isPremium) {
      return;
    }

    setQuestionStarted(true);
    setQuestionsAnswered(0);
    setCorrectAnswers(0);
    
    const question = await generateQuestion({
      topic: selectedTopic,
      difficulty: selectedDifficulty,
      context: "exercicio",
    });
    
    if (question) {
      setCurrentQuestion(question);
    }
  };

  const handleAnswer = (isCorrect: boolean) => {
    setQuestionsAnswered((prev) => prev + 1);
    if (isCorrect) {
      setCorrectAnswers((prev) => prev + 1);
    }

    // Record the answer in the database
    if (currentQuestion) {
      recordAnswer.mutate({
        topicId: selectedTopic,
        questionId: currentQuestion.id,
        isCorrect,
        timeTakenSeconds: 0,
      });
    }
  };

  const handleNextQuestion = async () => {
    const question = await generateQuestion({
      topic: selectedTopic,
      difficulty: selectedDifficulty,
      context: "exercicio",
    });
    
    if (question) {
      setCurrentQuestion(question);
    }
  };

  const handleChangeTopic = () => {
    setQuestionStarted(false);
    setCurrentQuestion(null);
    setQuestionsAnswered(0);
    setCorrectAnswers(0);
  };

  const topicData = topics.find((t) => t.id === selectedTopic);
  const showPremiumBlock = topicData?.isPremium && !isPremium;

  return (
    <Layout>
      {/* Header */}
      <section className="bg-muted/30 py-12">
        <div className="container">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-white">
              <Target className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-display text-3xl font-bold text-foreground">
                Exercícios
              </h1>
              <p className="text-muted-foreground">
                Pratique com questões geradas por IA
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-12">
        {!questionStarted ? (
          /* Topic Selection */
          <div className="mx-auto max-w-xl">
            <div className="rounded-2xl bg-card p-8 shadow-medium">
              <div className="mb-6 flex items-center justify-center gap-2 text-primary">
                <Sparkles className="h-5 w-5" />
                <span className="text-sm font-medium">Questões geradas por IA</span>
              </div>

              <h2 className="mb-6 text-center font-display text-xl font-semibold">
                Escolha um tema para praticar
              </h2>

              <div className="space-y-4">
                <Select value={selectedTopic} onValueChange={setSelectedTopic}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um tema" />
                  </SelectTrigger>
                  <SelectContent>
                    {topics.map((topic) => (
                      <SelectItem
                        key={topic.id}
                        value={topic.id}
                        disabled={topic.isPremium && !isPremium}
                      >
                        <div className="flex items-center gap-2">
                          {topic.name}
                          {topic.isPremium && !isPremium && (
                            <Lock className="h-3 w-3 text-muted-foreground" />
                          )}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={selectedDifficulty} 
                  onValueChange={(v) => setSelectedDifficulty(v as "easy" | "medium" | "hard")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a dificuldade" />
                  </SelectTrigger>
                  <SelectContent>
                    {difficultyOptions.map((diff) => (
                      <SelectItem key={diff.id} value={diff.id}>
                        {diff.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="mt-6">
                {showPremiumBlock ? (
                  <div className="rounded-xl bg-premium/10 p-4 text-center">
                    <Crown className="mx-auto mb-2 h-8 w-8 text-premium" />
                    <p className="mb-3 text-sm text-muted-foreground">
                      Este tema é exclusivo para assinantes Premium
                    </p>
                    <Link to="/assinatura">
                      <Button className="gap-2">
                        <Crown className="h-4 w-4" />
                        Desbloquear com Premium
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <Button
                    onClick={startExercise}
                    className="w-full gap-2"
                    size="lg"
                    disabled={!selectedTopic || isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Gerando questão...
                      </>
                    ) : (
                      <>
                        Começar Exercícios
                        <ChevronRight className="h-4 w-4" />
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </div>
        ) : (
          /* Question View */
          <div className="mx-auto max-w-3xl">
            {/* Question Header */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Badge variant="outline">
                  {topics.find((t) => t.id === selectedTopic)?.name}
                </Badge>
                <Badge variant="secondary">
                  {difficultyOptions.find((d) => d.id === selectedDifficulty)?.name}
                </Badge>
                {questionsAnswered > 0 && (
                  <Badge variant="outline" className="bg-success/10 text-success">
                    {correctAnswers}/{questionsAnswered} acertos
                  </Badge>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={handleChangeTopic}>
                Trocar tema
              </Button>
            </div>

            {/* Question */}
            {isLoading && !currentQuestion ? (
              <div className="flex flex-col items-center justify-center rounded-2xl bg-card p-12 shadow-medium">
                <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
                <p className="text-muted-foreground">Gerando questão com IA...</p>
              </div>
            ) : currentQuestion ? (
              <QuestionCard
                question={currentQuestion}
                onAnswer={handleAnswer}
                onNext={handleNextQuestion}
                isLoadingNext={isLoading}
              />
            ) : (
              <div className="rounded-2xl bg-card p-8 shadow-medium text-center">
                <p className="text-muted-foreground mb-4">
                  Não foi possível gerar a questão. Tente novamente.
                </p>
                <Button onClick={startExercise}>Tentar novamente</Button>
              </div>
            )}
          </div>
        )}
      </section>
    </Layout>
  );
}

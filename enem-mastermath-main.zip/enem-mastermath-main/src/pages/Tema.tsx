import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ChevronLeft,
  BookOpen,
  CheckCircle,
  Crown,
  Lightbulb,
  Target,
  Clock,
  Percent,
  HelpCircle,
} from "lucide-react";
import { getTopicById, topicsContent } from "@/data/topicsContent";

export default function TemaPage() {
  const { id } = useParams<{ id: string }>();
  const topic = id ? getTopicById(id) : null;

  if (!topic) {
    return (
      <Layout>
        <div className="container py-20 text-center">
          <h1 className="mb-4 font-display text-2xl font-bold">Tema não encontrado</h1>
          <Link to="/temas">
            <Button>Voltar aos Temas</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const relatedTopicsData = topic.relatedTopics
    .map((topicId) => ({
      id: topicId,
      title: topicsContent[topicId]?.title || topicId,
    }))
    .filter((t) => t.title);

  return (
    <Layout>
      {/* Header */}
      <section className="bg-muted/30 py-8">
        <div className="container">
          <Link
            to="/temas"
            className="mb-4 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ChevronLeft className="h-4 w-4" />
            Voltar aos Temas
          </Link>

          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="mb-2 font-display text-3xl font-bold text-foreground">
                {topic.title}
              </h1>
              <p className="text-muted-foreground">{topic.description}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="gap-1 text-sm">
                <Percent className="h-3 w-3" />
                {topic.percentage}% no ENEM
              </Badge>
              {topic.isPremium && (
                <span className="premium-badge">
                  <Crown className="h-3 w-3" />
                  Premium
                </span>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="container py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Theory */}
            <div className="rounded-2xl bg-card p-6 shadow-medium">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <h2 className="font-display text-xl font-semibold">Teoria Completa</h2>
              </div>

              <div className="space-y-6">
                {topic.theory.map((paragraph, index) => (
                  <div key={index} className="prose prose-sm max-w-none">
                    <p className="text-foreground leading-relaxed whitespace-pre-line">
                      {paragraph.split(/(\*\*[^*]+\*\*)/).map((part, i) => {
                        if (part.startsWith("**") && part.endsWith("**")) {
                          return (
                            <strong key={i} className="text-primary font-semibold">
                              {part.slice(2, -2)}
                            </strong>
                          );
                        }
                        return part;
                      })}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary */}
            <div className="rounded-2xl bg-primary/5 p-6">
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <Lightbulb className="h-5 w-5 text-primary" />
                </div>
                <h2 className="font-display text-xl font-semibold">Resumo para Revisão</h2>
              </div>

              <ul className="space-y-3">
                {topic.summary.map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-success" />
                    <span className="text-sm text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Solved Examples */}
            <div className="rounded-2xl bg-card p-6 shadow-medium">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
                  <Target className="h-5 w-5 text-accent" />
                </div>
                <h2 className="font-display text-xl font-semibold">
                  Questões Resolvidas do ENEM
                </h2>
              </div>

              <div className="space-y-6">
                {topic.solvedExamples.map((example, index) => (
                  <div
                    key={index}
                    className="rounded-xl border border-border bg-muted/30 p-5"
                  >
                    <div className="mb-3 flex items-center gap-2">
                      <Badge variant="outline">ENEM {example.year}</Badge>
                      <Badge variant="secondary" className="gap-1">
                        <HelpCircle className="h-3 w-3" />
                        Questão {index + 1}
                      </Badge>
                    </div>
                    <p className="mb-4 text-foreground leading-relaxed">{example.statement}</p>

                    <div className="rounded-lg bg-card p-4 border border-border">
                      <p className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                        Resolução Passo a Passo
                      </p>
                      <pre className="whitespace-pre-wrap font-sans text-sm text-foreground leading-relaxed">
                        {example.solution}
                      </pre>
                      <div className="mt-4 flex items-center gap-2 border-t border-border pt-4">
                        <CheckCircle className="h-5 w-5 text-success" />
                        <span className="text-sm font-semibold text-success">
                          Resposta: {example.answer}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Progress Card */}
            <div className="rounded-2xl bg-card p-6 shadow-medium">
              <h3 className="mb-4 font-display font-semibold">Seu Progresso</h3>
              <div className="mb-4 h-2 w-full overflow-hidden rounded-full bg-muted">
                <div className="h-full w-0 rounded-full bg-primary transition-all" />
              </div>
              <p className="mb-4 text-sm text-muted-foreground">
                0% concluído - Comece a estudar!
              </p>
              <Link to="/exercicios">
                <Button className="w-full gap-2">
                  <Target className="h-4 w-4" />
                  Praticar Exercícios
                </Button>
              </Link>
            </div>

            {/* Quick Stats */}
            <div className="rounded-2xl bg-muted/50 p-6">
              <h3 className="mb-4 font-display font-semibold">Sobre este Tema</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Percent className="h-4 w-4" />
                    Presença no ENEM
                  </span>
                  <span className="font-semibold text-primary">{topic.percentage}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <HelpCircle className="h-4 w-4" />
                    Questões disponíveis
                  </span>
                  <span className="font-semibold">{topic.questionsCount}+</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    Tempo estimado
                  </span>
                  <span className="font-semibold">{topic.estimatedTime}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <BookOpen className="h-4 w-4" />
                    Exemplos resolvidos
                  </span>
                  <span className="font-semibold">{topic.solvedExamples.length}</span>
                </div>
              </div>
            </div>

            {/* Related Topics */}
            {relatedTopicsData.length > 0 && (
              <div className="rounded-2xl bg-card p-6 shadow-medium">
                <h3 className="mb-4 font-display font-semibold">Temas Relacionados</h3>
                <div className="space-y-2">
                  {relatedTopicsData.map((relatedTopic) => (
                    <Link
                      key={relatedTopic.id}
                      to={`/tema/${relatedTopic.id}`}
                      className="block rounded-lg bg-muted/50 p-3 text-sm transition-colors hover:bg-muted"
                    >
                      {relatedTopic.title}
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* CTA for Premium */}
            {topic.isPremium && (
              <div className="rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 p-6 border border-primary/20">
                <div className="mb-3 flex items-center gap-2">
                  <Crown className="h-5 w-5 text-primary" />
                  <h3 className="font-display font-semibold">Conteúdo Premium</h3>
                </div>
                <p className="mb-4 text-sm text-muted-foreground">
                  Desbloqueie todos os temas, exercícios ilimitados e recursos exclusivos.
                </p>
                <Link to="/assinatura">
                  <Button variant="default" className="w-full">
                    Ver Planos
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </section>
    </Layout>
  );
}

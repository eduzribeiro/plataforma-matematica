import { Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { BookOpen, Target, Trophy, BarChart3, Crown, ArrowRight, CheckCircle, Flame, Calculator, Sparkles } from "lucide-react";
const features = [{
  icon: <BookOpen className="h-6 w-6" />,
  title: "Teoria Completa",
  description: "Todo o conteúdo de matemática cobrado no ENEM, explicado de forma clara e objetiva"
}, {
  icon: <Target className="h-6 w-6" />,
  title: "Exercícios Ilimitados",
  description: "Questões geradas por IA para você praticar sem nunca repetir o mesmo problema"
}, {
  icon: <Trophy className="h-6 w-6" />,
  title: "Desafios Cronometrados",
  description: "Simule o dia da prova com questões inéditas e tempo limitado"
}, {
  icon: <BarChart3 className="h-6 w-6" />,
  title: "Acompanhe seu Progresso",
  description: "Veja sua evolução com estatísticas detalhadas de acertos e tempo de estudo"
}];
const Index = () => {
  return <Layout>
      {/* Hero Section */}
      <section className="hero-gradient relative overflow-hidden py-20 text-white lg:py-28">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute left-10 top-10 text-6xl font-bold">∫</div>
          <div className="absolute right-20 top-20 text-5xl font-bold">∑</div>
          <div className="absolute bottom-20 left-1/4 text-4xl font-bold">π</div>
          <div className="absolute bottom-10 right-10 text-5xl font-bold">√</div>
          <div className="absolute left-1/2 top-1/3 text-3xl font-bold">Δ</div>
        </div>

        <div className="container relative">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm backdrop-blur-sm">
              <Flame className="h-4 w-4 text-accent" />
              <span>Diversos alunos já melhoraram suas notas</span>
            </div>

            <h1 className="mb-6 font-display text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
              Domine a Matemática do{" "}
              <span className="text-gradient-accent">ENEM</span>
            </h1>

            <p className="mb-8 text-lg text-white/80 md:text-xl">
              A plataforma mais completa de preparação em matemática. 
              Teoria, exercícios personalizados e simulados para você 
              alcançar a nota dos seus sonhos.
            </p>

            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link to="/login">
                <Button size="lg" className="gap-2 bg-accent text-white hover:bg-accent/90">
                  Começar Agora
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/assinatura">
                <Button size="lg" variant="outline" className="gap-2 border-white/30 bg-white/10 text-white hover:bg-white/20">
                  <Crown className="h-4 w-4" />
                  Ver Planos
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-sm text-white/60">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Questões atualizadas</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>IA integrada</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Teoria completa</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="container -mt-8 relative z-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Questões Resolvidas" value="0" subtitle="Comece a praticar!" icon={<Calculator className="h-6 w-6" />} />
          <StatCard title="Taxa de Acerto" value="0%" icon={<Target className="h-6 w-6" />} colorClass="text-success" />
          <StatCard title="Dias de Estudo" value="0" icon={<Flame className="h-6 w-6" />} colorClass="text-accent" />
          <StatCard title="Horas Estudadas" value="0h" icon={<BarChart3 className="h-6 w-6" />} colorClass="text-primary" />
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-20">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-display text-3xl font-bold text-foreground">
            Tudo que você precisa para gabaritar
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Nossa plataforma oferece uma experiência completa de aprendizado, 
            combinando teoria, prática e tecnologia de ponta.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => <div key={index} className="rounded-2xl bg-card p-6 shadow-soft transition-shadow hover:shadow-medium">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                {feature.icon}
              </div>
              <h3 className="mb-2 font-display font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>)}
        </div>
      </section>

      {/* Quick Actions */}
      <section className="container py-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* Topics Card */}
          <Link to="/temas" className="group">
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary to-primary/80 p-8 text-white shadow-medium transition-transform hover:scale-[1.02]">
              <div className="relative z-10">
                <BookOpen className="mb-4 h-10 w-10" />
                <h3 className="mb-2 font-display text-2xl font-bold">Temas</h3>
                <p className="mb-4 text-white/80">
                  Estude teoria completa de todos os 10 temas de matemática do ENEM
                </p>
                <span className="inline-flex items-center gap-2 text-sm font-medium">
                  Estudar <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
              <div className="absolute -bottom-4 -right-4 text-[120px] font-bold leading-none text-white/10">
                📚
              </div>
            </div>
          </Link>

          {/* Exercises Card */}
          <Link to="/exercicios" className="group">
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-accent to-accent/80 p-8 text-white shadow-medium transition-transform hover:scale-[1.02]">
              <div className="relative z-10">
                <Target className="mb-4 h-10 w-10" />
                <h3 className="mb-2 font-display text-2xl font-bold">Exercícios</h3>
                <p className="mb-4 text-white/80">
                  Pratique com questões geradas por IA organizadas por tema
                </p>
                <span className="inline-flex items-center gap-2 text-sm font-medium">
                  Acessar <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
              <div className="absolute -bottom-4 -right-4 text-[120px] font-bold leading-none text-white/10">
                ?
              </div>
            </div>
          </Link>

          {/* Challenges Card */}
          <Link to="/desafios" className="group">
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-success to-success/80 p-8 text-white shadow-medium transition-transform hover:scale-[1.02]">
              <div className="relative z-10">
                <Trophy className="mb-4 h-10 w-10" />
                <h3 className="mb-2 font-display text-2xl font-bold">Desafios</h3>
                <p className="mb-4 text-white/80">
                  Teste seus conhecimentos com questões cronometradas
                </p>
                <span className="inline-flex items-center gap-2 text-sm font-medium">
                  Iniciar <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
              <div className="absolute -bottom-4 -right-4 text-[120px] font-bold leading-none text-white/10">
                ⏱
              </div>
            </div>
          </Link>

          {/* Progress Card */}
          <Link to="/progresso" className="group">
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-purple-500 to-purple-500/80 p-8 text-white shadow-medium transition-transform hover:scale-[1.02]">
              <div className="relative z-10">
                <BarChart3 className="mb-4 h-10 w-10" />
                <h3 className="mb-2 font-display text-2xl font-bold">Progresso</h3>
                <p className="mb-4 text-white/80">
                  Acompanhe sua evolução e identifique pontos de melhoria
                </p>
                <span className="inline-flex items-center gap-2 text-sm font-medium">
                  Ver estatísticas <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
              <div className="absolute -bottom-4 -right-4 text-[120px] font-bold leading-none text-white/10">
                📊
              </div>
            </div>
          </Link>
        </div>

        {/* AI Notice */}
        <div className="mt-8 rounded-2xl bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/20 p-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h3 className="font-display font-semibold text-foreground">Questões Inteligentes com IA</h3>
          </div>
          <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
            Nossa plataforma utiliza Inteligência Artificial para gerar questões personalizadas. 
            A IA analisa suas dificuldades e adapta os exercícios para otimizar seu aprendizado, 
            criando questões inéditas no estilo ENEM.
          </p>
        </div>
      </section>



      {/* CTA Section */}
      <section className="container pb-20">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-primary via-primary to-accent p-8 text-white md:p-12">
          <div className="relative z-10 mx-auto max-w-2xl text-center">
            <Crown className="mx-auto mb-4 h-12 w-12" />
            <h2 className="mb-4 font-display text-3xl font-bold md:text-4xl">
              Desbloqueie todo o conteúdo
            </h2>
            <p className="mb-8 text-white/80">
              Assine o plano Premium e tenha acesso a todos os temas, exercícios ilimitados 
              gerados por IA, desafios exclusivos e muito mais!
            </p>
            <Link to="/assinatura">
              <Button size="lg" className="gap-2 bg-white text-primary hover:bg-white/90">
                <Crown className="h-5 w-5" />
                Começar Agora - 7 dias grátis
              </Button>
            </Link>
          </div>

          {/* Decorative Elements */}
          <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-white/10" />
          <div className="absolute -bottom-10 -right-10 h-60 w-60 rounded-full bg-white/10" />
        </div>
      </section>
    </Layout>;
};
export default Index;
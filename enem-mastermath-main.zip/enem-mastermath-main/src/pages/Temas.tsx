import { Layout } from "@/components/Layout";
import { TopicCard } from "@/components/TopicCard";
import { Input } from "@/components/ui/input";
import {
  Search,
  Shapes,
  Percent,
  BarChart3,
  TrendingUp,
  Grid3X3,
  PieChart,
  Ruler,
  FunctionSquare,
  Sigma,
  Binary,
} from "lucide-react";
import { useState } from "react";

const mathTopics = [
  {
    id: "geometria-plana",
    title: "Geometria Plana",
    description: "Áreas, perímetros, teorema de Pitágoras, semelhança de triângulos e polígonos",
    icon: <Shapes className="h-6 w-6" />,
    percentage: 18,
    questionsCount: 45,
    isPremium: false,
    colorClass: "bg-primary",
  },
  {
    id: "porcentagem",
    title: "Porcentagem e Juros",
    description: "Porcentagem, juros simples e compostos, descontos e acréscimos",
    icon: <Percent className="h-6 w-6" />,
    percentage: 15,
    questionsCount: 38,
    isPremium: false,
    colorClass: "bg-accent",
  },
  {
    id: "estatistica",
    title: "Estatística",
    description: "Média, mediana, moda, desvio padrão, gráficos e tabelas",
    icon: <BarChart3 className="h-6 w-6" />,
    percentage: 14,
    questionsCount: 35,
    isPremium: false,
    colorClass: "bg-success",
  },
  {
    id: "funcoes",
    title: "Funções",
    description: "Função afim, quadrática, exponencial e logarítmica",
    icon: <TrendingUp className="h-6 w-6" />,
    percentage: 12,
    questionsCount: 30,
    isPremium: true,
    colorClass: "bg-primary",
  },
  {
    id: "geometria-espacial",
    title: "Geometria Espacial",
    description: "Volumes, áreas de superfície, prismas, pirâmides, cilindros e cones",
    icon: <Grid3X3 className="h-6 w-6" />,
    percentage: 10,
    questionsCount: 25,
    isPremium: true,
    colorClass: "bg-accent",
  },
  {
    id: "probabilidade",
    title: "Probabilidade",
    description: "Probabilidade simples, condicional e análise combinatória",
    icon: <PieChart className="h-6 w-6" />,
    percentage: 9,
    questionsCount: 22,
    isPremium: true,
    colorClass: "bg-success",
  },
  {
    id: "razao-proporcao",
    title: "Razão e Proporção",
    description: "Regra de três simples e composta, escalas e grandezas proporcionais",
    icon: <Ruler className="h-6 w-6" />,
    percentage: 8,
    questionsCount: 20,
    isPremium: true,
    colorClass: "bg-primary",
  },
  {
    id: "algebra",
    title: "Álgebra",
    description: "Equações, inequações, sistemas lineares e matrizes",
    icon: <FunctionSquare className="h-6 w-6" />,
    percentage: 7,
    questionsCount: 18,
    isPremium: true,
    colorClass: "bg-accent",
  },
  {
    id: "progressoes",
    title: "Progressões",
    description: "Progressão aritmética (PA) e progressão geométrica (PG)",
    icon: <Sigma className="h-6 w-6" />,
    percentage: 4,
    questionsCount: 12,
    isPremium: true,
    colorClass: "bg-success",
  },
  {
    id: "trigonometria",
    title: "Trigonometria",
    description: "Razões trigonométricas, lei dos senos e cossenos, círculo trigonométrico",
    icon: <Binary className="h-6 w-6" />,
    percentage: 3,
    questionsCount: 10,
    isPremium: true,
    colorClass: "bg-primary",
  },
];

export default function TemasPage() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTopics = mathTopics.filter(
    (topic) =>
      topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      topic.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      {/* Header */}
      <section className="bg-muted/30 py-12">
        <div className="container">
          <h1 className="mb-4 font-display text-3xl font-bold text-foreground md:text-4xl">
            Temas de Matemática
          </h1>
          <p className="mb-8 max-w-2xl text-muted-foreground">
            Explore todo o conteúdo de matemática cobrado no ENEM. 
            Cada tema inclui teoria completa, resumo, exemplos resolvidos e exercícios.
          </p>

          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar tema..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="container py-12">
        {/* Stats Bar */}
        <div className="mb-8 flex flex-wrap items-center gap-6 rounded-xl bg-card p-4 shadow-soft">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-primary">{mathTopics.length}</span>
            <span className="text-sm text-muted-foreground">temas disponíveis</span>
          </div>
          <div className="h-8 w-px bg-border" />
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-accent">
              {mathTopics.reduce((acc, t) => acc + t.questionsCount, 0)}
            </span>
            <span className="text-sm text-muted-foreground">questões no total</span>
          </div>
          <div className="h-8 w-px bg-border" />
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-success">
              {mathTopics.filter((t) => !t.isPremium).length}
            </span>
            <span className="text-sm text-muted-foreground">temas gratuitos</span>
          </div>
        </div>

        {/* Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredTopics.map((topic) => (
            <TopicCard
              key={topic.id}
              title={topic.title}
              description={topic.description}
              icon={topic.icon}
              percentage={topic.percentage}
              questionsCount={topic.questionsCount}
              isPremium={topic.isPremium}
              isLocked={topic.isPremium}
              href={`/tema/${topic.id}`}
              colorClass={topic.colorClass}
            />
          ))}
        </div>

        {filteredTopics.length === 0 && (
          <div className="py-12 text-center">
            <p className="text-muted-foreground">Nenhum tema encontrado para "{searchQuery}"</p>
          </div>
        )}
      </section>
    </Layout>
  );
}

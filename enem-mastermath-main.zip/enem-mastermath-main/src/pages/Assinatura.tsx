import { useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Crown,
  Check,
  Star,
  Sparkles,
  Brain,
  Clock,
  BarChart3,
  Infinity,
  MessageCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const benefits = [
  {
    icon: <Brain className="h-6 w-6" />,
    title: "IA que Aprende com Você",
    description: "Questões personalizadas baseadas no seu desempenho e dificuldades",
  },
  {
    icon: <Infinity className="h-6 w-6" />,
    title: "Exercícios Infinitos",
    description: "Nunca repita a mesma questão - novas questões geradas automaticamente",
  },
  {
    icon: <Clock className="h-6 w-6" />,
    title: "Simulados Realistas",
    description: "Simule o dia da prova com cronômetro e condições reais",
  },
  {
    icon: <BarChart3 className="h-6 w-6" />,
    title: "Análise Detalhada",
    description: "Identifique seus pontos fracos e veja sua evolução",
  },
];

export default function AssinaturaPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, subscription, refreshSubscription } = useAuth();
  const { toast } = useToast();

  // Handle success callback
  useEffect(() => {
    if (searchParams.get("status") === "success") {
      toast({
        title: "Solicitação enviada! 🎉",
        description: "Entraremos em contato pelo WhatsApp para finalizar sua assinatura.",
      });
      refreshSubscription();
    }
  }, [searchParams, toast, refreshSubscription]);

  const handleSubscribe = () => {
    if (!user) {
      navigate("/login");
      return;
    }

    // Redirecionar para WhatsApp
    const phoneNumber = "5535991973825";
    const message = encodeURIComponent("Quero realizar a assinatura premium!");
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(whatsappUrl, "_blank");
  };

  const plans = [
    {
      name: "Gratuito",
      price: "R$ 0",
      period: "",
      description: "Experimente a plataforma",
      features: [
        "3 temas de matemática",
        "10 exercícios por tema",
        "Desafio Rápido",
        "Estatísticas básicas",
      ],
      notIncluded: [
        "Todos os temas",
        "Exercícios ilimitados com IA",
        "Simulados completos",
        "Desafios semanais",
      ],
      buttonText: !user ? "Criar Conta Grátis" : "Plano Atual",
      buttonAction: !user ? () => navigate("/login") : undefined,
      buttonVariant: "outline" as const,
      popular: false,
      isCurrent: user && !subscription.subscribed,
    },
    {
      name: "Premium",
      price: "R$ 19,90",
      period: "/mês",
      description: "Acesso completo à plataforma",
      features: [
        "Todos os 10 temas de matemática",
        "Exercícios ilimitados com IA",
        "Todos os simulados e desafios",
        "Estatísticas detalhadas",
        "Desafios semanais exclusivos",
        "Suporte prioritário",
      ],
      notIncluded: [],
      buttonText: subscription.subscribed ? "Assinatura Ativa" : "Assinar Premium",
      buttonAction: subscription.subscribed ? undefined : handleSubscribe,
      buttonVariant: "default" as const,
      popular: true,
      isCurrent: subscription.subscribed,
    },
  ];

  return (
    <Layout>
      {/* Header */}
      <section className="hero-gradient py-16 text-white">
        <div className="container text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm backdrop-blur-sm">
            <Sparkles className="h-4 w-4 text-premium" />
            <span>Desbloqueie todo o potencial</span>
          </div>

          <h1 className="mb-4 font-display text-4xl font-bold md:text-5xl">
            {subscription.subscribed ? "Sua Assinatura Premium" : "Escolha seu plano"}
          </h1>
          <p className="mx-auto max-w-2xl text-lg text-white/80">
            {subscription.subscribed 
              ? "Aproveite todos os recursos exclusivos para dominar a matemática do ENEM!"
              : "Invista no seu futuro com acesso completo a toda a plataforma. Milhares de estudantes já melhoraram suas notas com nossa metodologia."}
          </p>

          {subscription.subscribed && subscription.subscriptionEnd && (
            <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-2 text-sm">
              <Crown className="h-4 w-4" />
              Próxima cobrança em {new Date(subscription.subscriptionEnd).toLocaleDateString("pt-BR")}
            </div>
          )}
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="container -mt-8 relative z-10 pb-16">
        <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-2">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={cn(
                "relative overflow-hidden rounded-2xl bg-card p-6 shadow-medium",
                plan.popular && "ring-2 ring-primary",
                plan.isCurrent && "ring-2 ring-success"
              )}
            >
              {plan.popular && !plan.isCurrent && (
                <div className="absolute -right-8 top-6 rotate-45 bg-primary px-10 py-1 text-xs font-semibold text-primary-foreground">
                  Popular
                </div>
              )}

              {plan.isCurrent && (
                <Badge className="mb-4 bg-success text-success-foreground">
                  Seu Plano Atual
                </Badge>
              )}

              <h3 className="mb-2 font-display text-xl font-semibold">{plan.name}</h3>
              <div className="mb-4">
                <span className="font-display text-4xl font-bold text-foreground">
                  {plan.price}
                </span>
                <span className="text-muted-foreground">{plan.period}</span>
              </div>
              <p className="mb-6 text-sm text-muted-foreground">{plan.description}</p>

              <Button
                variant={plan.buttonVariant}
                className={cn(
                  "mb-6 w-full gap-2",
                  plan.popular && !plan.isCurrent && "bg-primary hover:bg-primary/90"
                )}
                onClick={plan.buttonAction}
                disabled={(plan.name === "Gratuito" && user && !subscription.subscribed) || (plan.name === "Premium" && subscription.subscribed)}
              >
                {plan.popular && !plan.isCurrent ? (
                  <MessageCircle className="h-4 w-4" />
                ) : plan.isCurrent ? (
                  <Crown className="h-4 w-4" />
                ) : null}
                {plan.buttonText}
              </Button>

              <div className="space-y-3">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-success" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </div>
                ))}
                {plan.notIncluded.map((feature, i) => (
                  <div key={i} className="flex items-start gap-3 opacity-50">
                    <div className="mt-0.5 h-4 w-4 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground line-through">
                      {feature}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-muted/30 py-16">
        <div className="container">
          <h2 className="mb-12 text-center font-display text-3xl font-bold">
            Por que ser Premium?
          </h2>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="rounded-2xl bg-card p-6 text-center shadow-soft"
              >
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  {benefit.icon}
                </div>
                <h3 className="mb-2 font-display font-semibold">{benefit.title}</h3>
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Guarantee */}
      {!subscription.subscribed && (
        <section className="container py-16">
          <div className="mx-auto max-w-2xl rounded-2xl bg-gradient-to-r from-primary to-accent p-8 text-center text-white">
            <Star className="mx-auto mb-4 h-12 w-12" />
            <h2 className="mb-4 font-display text-2xl font-bold">
              Garantia de 7 dias
            </h2>
            <p className="mb-6 text-white/80">
              Experimente o Premium sem riscos. Se não gostar, devolvemos 100% do seu dinheiro 
              nos primeiros 7 dias, sem perguntas.
            </p>
            <Button 
              size="lg" 
              className="gap-2 bg-white text-primary hover:bg-white/90"
              onClick={handleSubscribe}
            >
              <MessageCircle className="h-5 w-5" />
              Falar no WhatsApp
            </Button>
          </div>
        </section>
      )}
    </Layout>
  );
}

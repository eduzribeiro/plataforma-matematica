import { useState, useEffect, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Trophy,
  Clock,
  Play,
  CheckCircle,
  XCircle,
  ChevronRight,
  Crown,
  Flame,
  Target,
  AlertCircle,
  Loader2,
  Sparkles,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useGenerateQuestion, type GeneratedQuestion } from "@/hooks/useGenerateQuestion";
import { useAuth } from "@/contexts/AuthContext";
import { useRecordAnswer } from "@/hooks/useProgress";

const challenges = [
  {
    id: 1,
    title: "Desafio Rápido",
    description: "5 questões em 10 minutos",
    questions: 5,
    timeMinutes: 10,
    difficulty: "easy" as const,
    difficultyLabel: "Fácil",
    isPremium: false,
    xpReward: 50,
    topics: ["geometria-plana", "porcentagem", "estatistica"],
  },
  {
    id: 2,
    title: "Simulado Express",
    description: "10 questões em 25 minutos",
    questions: 10,
    timeMinutes: 25,
    difficulty: "medium" as const,
    difficultyLabel: "Médio",
    isPremium: false,
    xpReward: 100,
    topics: ["geometria-plana", "porcentagem", "estatistica", "funcoes", "probabilidade"],
  },
  {
    id: 3,
    title: "Maratona ENEM",
    description: "45 questões em 3 horas (igual ao ENEM)",
    questions: 45,
    timeMinutes: 180,
    difficulty: "hard" as const,
    difficultyLabel: "Difícil",
    isPremium: true,
    xpReward: 500,
    topics: ["geometria-plana", "porcentagem", "estatistica", "funcoes", "geometria-espacial", "probabilidade", "razao-proporcao", "algebra", "progressoes", "trigonometria"],
  },
  {
    id: 4,
    title: "Desafio Semanal",
    description: "Questões especiais renovadas toda semana",
    questions: 15,
    timeMinutes: 40,
    difficulty: "medium" as const,
    difficultyLabel: "Variado",
    isPremium: true,
    xpReward: 200,
    topics: ["geometria-plana", "porcentagem", "estatistica", "funcoes", "probabilidade"],
  },
];

export default function DesafiosPage() {
  const { isPremium } = useAuth();
  const [activeChallenge, setActiveChallenge] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([]);
  const [answers, setAnswers] = useState<{ questionId: string; isCorrect: boolean }[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [isLoadingQuestion, setIsLoadingQuestion] = useState(false);

  const { generateQuestion } = useGenerateQuestion();
  const recordAnswer = useRecordAnswer();

  const challenge = activeChallenge ? challenges.find((c) => c.id === activeChallenge) : null;

  // Timer logic
  useEffect(() => {
    if (activeChallenge && timeLeft > 0 && !showResult) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && activeChallenge && !showResult && questions.length > 0) {
      setShowResult(true);
    }
  }, [activeChallenge, timeLeft, showResult, questions.length]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getRandomTopic = useCallback((topics: string[]) => {
    return topics[Math.floor(Math.random() * topics.length)];
  }, []);

  const loadNextQuestion = useCallback(async (challengeData: typeof challenges[0]) => {
    setIsLoadingQuestion(true);
    const topic = getRandomTopic(challengeData.topics);
    const question = await generateQuestion({
      topic,
      difficulty: challengeData.difficulty,
      context: "desafio",
    });
    setIsLoadingQuestion(false);
    return question;
  }, [generateQuestion, getRandomTopic]);

  const startChallenge = async (challengeId: number) => {
    const challengeData = challenges.find((c) => c.id === challengeId);
    if (!challengeData) return;
    if (challengeData.isPremium && !isPremium) return;

    setActiveChallenge(challengeId);
    setTimeLeft(challengeData.timeMinutes * 60);
    setCurrentQuestionIndex(0);
    setQuestions([]);
    setAnswers([]);
    setShowResult(false);

    // Load first question
    const question = await loadNextQuestion(challengeData);
    if (question) {
      setQuestions([question]);
    }
  };

  const handleAnswer = async (isCorrect: boolean) => {
    const currentQuestion = questions[currentQuestionIndex];
    if (!currentQuestion || !challenge) return;

    const newAnswers = [...answers, { questionId: currentQuestion.id, isCorrect }];
    setAnswers(newAnswers);

    // Record answer
    recordAnswer.mutate({
      topicId: currentQuestion.topic,
      questionId: currentQuestion.id,
      isCorrect,
      timeTakenSeconds: 0,
    });

    // Check if challenge is complete
    if (newAnswers.length >= challenge.questions) {
      setShowResult(true);
    } else {
      // Load next question
      const nextQuestion = await loadNextQuestion(challenge);
      if (nextQuestion) {
        setQuestions((prev) => [...prev, nextQuestion]);
        setCurrentQuestionIndex((prev) => prev + 1);
      }
    }
  };

  const exitChallenge = () => {
    setActiveChallenge(null);
    setShowResult(false);
    setQuestions([]);
    setAnswers([]);
  };

  const getTimeClass = () => {
    if (timeLeft <= 60) return "timer-display danger";
    if (timeLeft <= 300) return "timer-display warning";
    return "timer-display";
  };

  const correctCount = answers.filter((a) => a.isCorrect).length;
  const accuracy = answers.length > 0 ? Math.round((correctCount / answers.length) * 100) : 0;

  // Active challenge view
  if (activeChallenge && !showResult && challenge) {
    const currentQuestion = questions[currentQuestionIndex];

    return (
      <Layout>
        <div className="container py-8">
          {/* Challenge Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="font-display text-2xl font-bold">{challenge.title}</h1>
              <p className="text-muted-foreground">
                Questão {currentQuestionIndex + 1} de {challenge.questions}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className={getTimeClass()}>
                <Clock className="h-5 w-5" />
                {formatTime(timeLeft)}
              </div>
              <Badge variant="outline" className="bg-success/10 text-success">
                {correctCount}/{answers.length} acertos
              </Badge>
              <Button variant="ghost" onClick={exitChallenge}>
                Sair
              </Button>
            </div>
          </div>

          {/* Question */}
          <div className="mx-auto max-w-3xl">
            {isLoadingQuestion && !currentQuestion ? (
              <div className="flex flex-col items-center justify-center rounded-2xl bg-card p-12 shadow-medium">
                <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
                <p className="text-muted-foreground">Gerando questão com IA...</p>
              </div>
            ) : currentQuestion ? (
              <ChallengeQuestionCard
                question={currentQuestion}
                onAnswer={handleAnswer}
                isLoading={isLoadingQuestion}
              />
            ) : (
              <div className="rounded-2xl bg-card p-8 shadow-medium text-center">
                <p className="text-muted-foreground mb-4">
                  Não foi possível carregar a questão. Tente novamente.
                </p>
                <Button onClick={() => startChallenge(activeChallenge)}>Reiniciar</Button>
              </div>
            )}
          </div>
        </div>
      </Layout>
    );
  }

  // Results view
  if (showResult && challenge) {
    const xpEarned = Math.round((correctCount / challenge.questions) * challenge.xpReward);

    return (
      <Layout>
        <div className="container py-12">
          <div className="mx-auto max-w-xl text-center">
            <div
              className={`mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full ${
                accuracy >= 70 ? "bg-success/10" : "bg-destructive/10"
              }`}
            >
              {accuracy >= 70 ? (
                <Trophy className="h-12 w-12 text-success" />
              ) : (
                <Target className="h-12 w-12 text-destructive" />
              )}
            </div>

            <h1 className="mb-4 font-display text-3xl font-bold">
              {accuracy >= 70 ? "Parabéns!" : "Continue Praticando!"}
            </h1>

            <p className="mb-8 text-muted-foreground">
              {accuracy >= 70
                ? `Excelente desempenho! Você acertou ${accuracy}% das questões.`
                : `Você acertou ${accuracy}% das questões. Pratique mais para melhorar!`}
            </p>

            <div className="mb-8 grid grid-cols-3 gap-4">
              <div className="rounded-xl bg-card p-4 shadow-soft">
                <p className="text-2xl font-bold text-primary">
                  {correctCount}/{answers.length}
                </p>
                <p className="text-xs text-muted-foreground">Acertos</p>
              </div>
              <div className="rounded-xl bg-card p-4 shadow-soft">
                <p className="text-2xl font-bold text-accent">{accuracy}%</p>
                <p className="text-xs text-muted-foreground">Taxa</p>
              </div>
              <div className="rounded-xl bg-card p-4 shadow-soft">
                <p className="text-2xl font-bold text-success">+{xpEarned}</p>
                <p className="text-xs text-muted-foreground">XP</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Button variant="outline" className="flex-1" onClick={exitChallenge}>
                Voltar aos Desafios
              </Button>
              <Button
                className="flex-1 gap-2"
                onClick={() => startChallenge(activeChallenge!)}
              >
                <Flame className="h-4 w-4" />
                Tentar Novamente
              </Button>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  // Challenges list view
  return (
    <Layout>
      {/* Header */}
      <section className="bg-muted/30 py-12">
        <div className="container">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-white">
              <Trophy className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-display text-3xl font-bold text-foreground">Desafios</h1>
              <p className="text-muted-foreground">
                Teste seus conhecimentos com questões cronometradas geradas por IA
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-12">
        {/* AI Badge */}
        <div className="mb-8 flex items-center justify-center gap-2 text-primary">
          <Sparkles className="h-5 w-5" />
          <span className="text-sm font-medium">Questões inéditas geradas por IA</span>
        </div>

        {/* Challenges Grid */}
        <div className="grid gap-6 md:grid-cols-2">
          {challenges.map((challenge) => (
            <div
              key={challenge.id}
              className="relative overflow-hidden rounded-2xl bg-card p-6 shadow-medium"
            >
              {challenge.isPremium && (
                <div className="absolute right-4 top-4">
                  <span className="premium-badge">
                    <Crown className="h-3 w-3" />
                    Premium
                  </span>
                </div>
              )}

              <div className="mb-4 flex items-start gap-4">
                <div
                  className={`flex h-14 w-14 items-center justify-center rounded-xl ${
                    challenge.isPremium ? "bg-premium/10" : "bg-accent/10"
                  }`}
                >
                  <Trophy
                    className={`h-7 w-7 ${
                      challenge.isPremium ? "text-premium" : "text-accent"
                    }`}
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-display text-xl font-semibold">{challenge.title}</h3>
                  <p className="text-sm text-muted-foreground">{challenge.description}</p>
                </div>
              </div>

              <div className="mb-6 flex flex-wrap items-center gap-3">
                <Badge variant="outline" className="gap-1">
                  <Target className="h-3 w-3" />
                  {challenge.questions} questões
                </Badge>
                <Badge variant="outline" className="gap-1">
                  <Clock className="h-3 w-3" />
                  {challenge.timeMinutes} min
                </Badge>
                <Badge
                  variant="secondary"
                  className={
                    challenge.difficultyLabel === "Fácil"
                      ? "bg-success/10 text-success"
                      : challenge.difficultyLabel === "Médio"
                      ? "bg-warning/10 text-warning"
                      : "bg-destructive/10 text-destructive"
                  }
                >
                  {challenge.difficultyLabel}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <Flame className="h-4 w-4 text-accent" />
                  <span className="font-medium">+{challenge.xpReward} XP</span>
                </div>

                {challenge.isPremium && !isPremium ? (
                  <Link to="/assinatura">
                    <Button variant="outline" className="gap-2">
                      <Crown className="h-4 w-4 text-premium" />
                      Desbloquear
                    </Button>
                  </Link>
                ) : (
                  <Button onClick={() => startChallenge(challenge.id)} className="gap-2">
                    <Play className="h-4 w-4" />
                    Iniciar
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Info Box */}
        <div className="mt-8 rounded-xl bg-primary/5 p-6">
          <div className="flex gap-4">
            <AlertCircle className="h-6 w-6 flex-shrink-0 text-primary" />
            <div>
              <h4 className="mb-1 font-semibold text-foreground">Como funcionam os desafios?</h4>
              <p className="text-sm text-muted-foreground">
                Os desafios são compostos por questões inéditas geradas por inteligência artificial,
                simulando o ambiente real da prova do ENEM. Complete os desafios para ganhar XP e
                acompanhar seu progresso na plataforma.
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

// Simplified question card for challenges (no explanation, auto-advance)
function ChallengeQuestionCard({
  question,
  onAnswer,
  isLoading,
}: {
  question: GeneratedQuestion;
  onAnswer: (isCorrect: boolean) => void;
  isLoading: boolean;
}) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  const isCorrect = selectedAnswer === question.correctAnswer;

  const handleSelectAnswer = (answerId: string) => {
    if (!showResult) {
      setSelectedAnswer(answerId);
    }
  };

  const handleConfirmAnswer = () => {
    if (!selectedAnswer) return;
    setShowResult(true);
  };

  const handleNext = () => {
    onAnswer(isCorrect);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  return (
    <div className="rounded-2xl bg-card p-8 shadow-medium">
      <p className="mb-8 text-lg leading-relaxed">{question.statement}</p>

      <div className="mb-8 space-y-3">
        {question.options.map((option) => {
          const isSelected = selectedAnswer === option.id;
          const isCorrectOption = option.id === question.correctAnswer;

          let optionClass =
            "flex cursor-pointer items-center gap-4 rounded-xl border-2 p-4 transition-all";

          if (showResult) {
            if (isCorrectOption) {
              optionClass += " border-success bg-success/10";
            } else if (isSelected && !isCorrectOption) {
              optionClass += " border-destructive bg-destructive/10";
            } else {
              optionClass += " border-border opacity-50";
            }
          } else if (isSelected) {
            optionClass += " border-primary bg-primary/5";
          } else {
            optionClass += " border-border hover:border-primary/50";
          }

          return (
            <div
              key={option.id}
              className={optionClass}
              onClick={() => handleSelectAnswer(option.id)}
            >
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-lg font-semibold ${
                  isSelected
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {option.id.toUpperCase()}
              </div>
              <span>{option.text}</span>
              {showResult && isCorrectOption && (
                <CheckCircle className="ml-auto h-5 w-5 text-success" />
              )}
              {showResult && isSelected && !isCorrectOption && (
                <XCircle className="ml-auto h-5 w-5 text-destructive" />
              )}
            </div>
          );
        })}
      </div>

      {!showResult ? (
        <Button
          onClick={handleConfirmAnswer}
          disabled={!selectedAnswer}
          className="w-full"
          size="lg"
        >
          Confirmar Resposta
        </Button>
      ) : (
        <div className="space-y-4">
          <div
            className={`rounded-xl p-4 text-center ${
              isCorrect ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
            }`}
          >
            <div className="flex items-center justify-center gap-2 text-lg font-semibold">
              {isCorrect ? (
                <>
                  <CheckCircle className="h-5 w-5" />
                  Correto!
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5" />
                  Incorreto
                </>
              )}
            </div>
          </div>

          <Button onClick={handleNext} className="w-full gap-2" size="lg" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Carregando próxima...
              </>
            ) : (
              <>
                Próxima Questão
                <ChevronRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}

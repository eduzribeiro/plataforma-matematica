import { Layout } from "@/components/Layout";
import { StatCard } from "@/components/StatCard";
import { ProgressRing } from "@/components/ProgressRing";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart3,
  Target,
  CheckCircle,
  XCircle,
  Clock,
  Flame,
  Trophy,
  Calendar,
  LogIn,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useStudyProgress, useUserStats, useAchievements, useUserAchievements } from "@/hooks/useProgress";

const topicNames: Record<string, string> = {
  "geometria-plana": "Geometria Plana",
  "porcentagem": "Porcentagem e Juros",
  "estatistica": "Estatística",
  "funcoes": "Funções",
  "geometria-espacial": "Geometria Espacial",
  "probabilidade": "Probabilidade",
  "razao-proporcao": "Razão e Proporção",
  "algebra": "Álgebra",
  "progressoes": "Progressões",
  "trigonometria": "Trigonometria",
};

export default function ProgressoPage() {
  const { user, loading: authLoading } = useAuth();
  const { data: progressData, isLoading: progressLoading } = useStudyProgress();
  const { data: statsData, isLoading: statsLoading } = useUserStats();
  const { data: achievements, isLoading: achievementsLoading } = useAchievements();
  const { data: userAchievements, isLoading: userAchievementsLoading } = useUserAchievements();

  const isLoading = authLoading || progressLoading || statsLoading || achievementsLoading || userAchievementsLoading;

  // Calculate aggregated stats
  const totalQuestions = progressData?.reduce((acc, p) => acc + p.questions_answered, 0) || 0;
  const correctAnswers = progressData?.reduce((acc, p) => acc + p.correct_answers, 0) || 0;
  const wrongAnswers = progressData?.reduce((acc, p) => acc + p.wrong_answers, 0) || 0;
  const accuracy = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0;
  
  const studyDays = statsData?.total_study_days || 0;
  const studyHours = Math.round(Number(statsData?.total_study_hours || 0));
  const totalXP = statsData?.xp_total || 0;
  const currentStreak = statsData?.current_streak || 0;

  // Build topic progress with all topics
  const topicProgress = Object.entries(topicNames).map(([id, name]) => {
    const progress = progressData?.find(p => p.topic_id === id);
    const total = progress?.questions_answered || 0;
    const correct = progress?.correct_answers || 0;
    const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;
    return { name, correct, total, percentage };
  });

  // Map user achievements
  const unlockedAchievementIds = new Set(userAchievements?.map(ua => ua.achievement_id) || []);

  if (!user && !authLoading) {
    return (
      <Layout>
        <section className="bg-muted/30 py-12">
          <div className="container">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success text-white">
                <BarChart3 className="h-6 w-6" />
              </div>
              <div>
                <h1 className="font-display text-3xl font-bold text-foreground">Meu Progresso</h1>
                <p className="text-muted-foreground">
                  Acompanhe sua evolução e identifique pontos de melhoria
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="container py-12">
          <div className="mx-auto max-w-md rounded-2xl bg-card p-8 text-center shadow-medium">
            <LogIn className="mx-auto mb-4 h-12 w-12 text-primary" />
            <h2 className="mb-2 font-display text-xl font-bold">Faça login para ver seu progresso</h2>
            <p className="mb-6 text-muted-foreground">
              Crie uma conta ou entre para acompanhar seu desempenho, conquistas e evolução.
            </p>
            <Link to="/login">
              <Button className="gap-2">
                <LogIn className="h-4 w-4" />
                Entrar ou Criar Conta
              </Button>
            </Link>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header */}
      <section className="bg-muted/30 py-12">
        <div className="container">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success text-white">
              <BarChart3 className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-display text-3xl font-bold text-foreground">Meu Progresso</h1>
              <p className="text-muted-foreground">
                Acompanhe sua evolução e identifique pontos de melhoria
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-12">
        {/* Stats Overview */}
        <div className="mb-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {isLoading ? (
            <>
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-32 rounded-2xl" />
              ))}
            </>
          ) : (
            <>
              <StatCard
                title="Questões Resolvidas"
                value={totalQuestions}
                icon={<Target className="h-6 w-6" />}
              />
              <StatCard
                title="Taxa de Acerto"
                value={`${accuracy}%`}
                icon={<CheckCircle className="h-6 w-6" />}
                colorClass="text-success"
              />
              <StatCard
                title="Dias de Estudo"
                value={studyDays}
                subtitle={currentStreak > 0 ? `Sequência atual: ${currentStreak} dias` : undefined}
                icon={<Calendar className="h-6 w-6" />}
                colorClass="text-accent"
              />
              <StatCard
                title="Tempo Total"
                value={`${studyHours}h`}
                icon={<Clock className="h-6 w-6" />}
                colorClass="text-primary"
              />
            </>
          )}
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Stats */}
          <div className="lg:col-span-2 space-y-8">
            {/* Accuracy Breakdown */}
            <div className="rounded-2xl bg-card p-6 shadow-medium">
              <h2 className="mb-6 font-display text-xl font-semibold">Desempenho Geral</h2>

              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Skeleton className="h-40 w-40 rounded-full" />
                </div>
              ) : totalQuestions === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  <Target className="mx-auto mb-4 h-12 w-12 opacity-50" />
                  <p>Você ainda não respondeu nenhuma questão.</p>
                  <Link to="/exercicios" className="mt-4 inline-block">
                    <Button variant="outline">Começar a Estudar</Button>
                  </Link>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-8 sm:flex-row sm:justify-around">
                  {/* Progress Ring */}
                  <ProgressRing progress={accuracy} size={150} strokeWidth={12}>
                    <div className="text-center">
                      <span className="font-display text-3xl font-bold text-foreground">
                        {accuracy}%
                      </span>
                      <p className="text-xs text-muted-foreground">Acertos</p>
                    </div>
                  </ProgressRing>

                  {/* Breakdown */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                        <CheckCircle className="h-5 w-5 text-success" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{correctAnswers} Corretas</p>
                        <p className="text-sm text-muted-foreground">
                          {Math.round((correctAnswers / totalQuestions) * 100)}% do total
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                        <XCircle className="h-5 w-5 text-destructive" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{wrongAnswers} Incorretas</p>
                        <p className="text-sm text-muted-foreground">
                          {Math.round((wrongAnswers / totalQuestions) * 100)}% do total
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Topic Progress */}
            <div className="rounded-2xl bg-card p-6 shadow-medium">
              <h2 className="mb-6 font-display text-xl font-semibold">Progresso por Tema</h2>

              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-8" />
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {topicProgress.map((topic, index) => (
                    <div key={index}>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">{topic.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {topic.total > 0 ? `${topic.correct}/${topic.total}` : "Não iniciado"}
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className={`h-full rounded-full transition-all ${
                            topic.percentage >= 70
                              ? "bg-success"
                              : topic.percentage >= 40
                              ? "bg-warning"
                              : topic.percentage > 0
                              ? "bg-destructive"
                              : "bg-muted"
                          }`}
                          style={{ width: `${topic.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* XP & Streak */}
            <div className="rounded-2xl bg-gradient-to-br from-accent to-accent/80 p-6 text-white shadow-medium">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame className="h-6 w-6" />
                  <span className="font-semibold">Sequência</span>
                </div>
                <span className="text-3xl font-bold">{isLoading ? "-" : currentStreak} dias</span>
              </div>
              <div className="flex items-center justify-between border-t border-white/20 pt-4">
                <div className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  <span className="text-sm">XP Total</span>
                </div>
                <span className="text-xl font-bold">{isLoading ? "-" : totalXP}</span>
              </div>
            </div>

            {/* Achievements */}
            <div className="rounded-2xl bg-card p-6 shadow-medium">
              <h3 className="mb-4 font-display font-semibold">Conquistas</h3>
              {isLoading ? (
                <div className="grid grid-cols-2 gap-3">
                  {[...Array(4)].map((_, i) => (
                    <Skeleton key={i} className="h-20 rounded-xl" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  {achievements?.slice(0, 6).map((achievement) => {
                    const isUnlocked = unlockedAchievementIds.has(achievement.id);
                    return (
                      <div
                        key={achievement.id}
                        className={`rounded-xl p-3 text-center transition-opacity ${
                          isUnlocked
                            ? "bg-muted"
                            : "bg-muted/50 opacity-50"
                        }`}
                        title={achievement.description}
                      >
                        <span className="mb-1 block text-2xl">{achievement.icon}</span>
                        <p className="text-xs font-medium text-foreground">
                          {achievement.name}
                        </p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

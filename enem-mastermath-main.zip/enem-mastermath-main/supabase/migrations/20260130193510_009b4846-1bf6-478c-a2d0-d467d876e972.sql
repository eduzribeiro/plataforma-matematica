-- Create a table to store fallback questions
CREATE TABLE public.questions_bank (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    topic_id TEXT NOT NULL,
    difficulty TEXT NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
    statement TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    option_e TEXT NOT NULL,
    correct_answer TEXT NOT NULL CHECK (correct_answer IN ('a', 'b', 'c', 'd', 'e')),
    explanation TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.questions_bank ENABLE ROW LEVEL SECURITY;

-- Everyone can read questions (they're public content)
CREATE POLICY "Anyone can view questions" 
ON public.questions_bank 
FOR SELECT 
USING (true);

-- Create index for faster queries by topic and difficulty
CREATE INDEX idx_questions_bank_topic_difficulty ON public.questions_bank(topic_id, difficulty);
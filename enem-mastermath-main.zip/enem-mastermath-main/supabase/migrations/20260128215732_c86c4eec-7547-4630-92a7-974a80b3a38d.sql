-- Criar tabela de assinaturas para gerenciamento manual de premium
CREATE TABLE public.subscriptions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL UNIQUE,
    is_premium BOOLEAN NOT NULL DEFAULT false,
    premium_since TIMESTAMP WITH TIME ZONE,
    premium_until TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

-- Política: Usuários podem ver sua própria assinatura
CREATE POLICY "Users can view their own subscription"
ON public.subscriptions
FOR SELECT
USING (auth.uid() = user_id);

-- Política: Sistema pode inserir (via trigger)
CREATE POLICY "System can insert subscriptions"
ON public.subscriptions
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Trigger para atualizar updated_at
CREATE TRIGGER update_subscriptions_updated_at
BEFORE UPDATE ON public.subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Criar registro de assinatura automaticamente quando usuário é criado
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (user_id, display_name)
    VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)));
    
    INSERT INTO public.user_stats (user_id)
    VALUES (NEW.id);
    
    INSERT INTO public.subscriptions (user_id, is_premium)
    VALUES (NEW.id, false);
    
    RETURN NEW;
END;
$$;

-- Comentário explicativo para o admin
COMMENT ON TABLE public.subscriptions IS 'Tabela para gerenciamento manual de assinaturas premium. Altere is_premium para true/false diretamente no banco para liberar/bloquear acesso.';
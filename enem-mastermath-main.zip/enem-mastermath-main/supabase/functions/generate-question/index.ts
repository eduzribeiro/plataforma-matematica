import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const topicPrompts: Record<string, string> = {
  "geometria-plana": "Geometria Plana (áreas, perímetros, ângulos, triângulos, quadriláteros, círculos)",
  "porcentagem": "Porcentagem e Juros (cálculos percentuais, juros simples e compostos, descontos)",
  "estatistica": "Estatística (média, mediana, moda, desvio padrão, interpretação de gráficos e tabelas)",
  "funcoes": "Funções (função afim, quadrática, exponencial, logarítmica, análise de gráficos)",
  "geometria-espacial": "Geometria Espacial (volume, área de superfície, prismas, pirâmides, cilindros, cones, esferas)",
  "probabilidade": "Probabilidade (eventos, espaço amostral, probabilidade condicional, combinatória básica)",
  "razao-proporcao": "Razão e Proporção (regra de três simples e composta, grandezas proporcionais, escalas)",
  "algebra": "Álgebra (equações, sistemas lineares, inequações, polinômios, fatoração)",
  "progressoes": "Progressões (PA e PG, termo geral, soma dos termos)",
  "trigonometria": "Trigonometria (seno, cosseno, tangente, relações trigonométricas, lei dos senos e cossenos)",
};

const difficultyInstructions: Record<string, string> = {
  easy: "Nível FÁCIL: questão direta, com poucos passos de resolução, conceitos básicos.",
  medium: "Nível MÉDIO: questão que exige 2-3 etapas de raciocínio, combinando conceitos.",
  hard: "Nível DIFÍCIL: questão complexa com múltiplas etapas, exigindo integração de conceitos e raciocínio elaborado.",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { topic, difficulty = "medium", context = "exercicio" } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const topicDescription = topicPrompts[topic] || topic;
    const difficultyInstruction = difficultyInstructions[difficulty] || difficultyInstructions.medium;

    const contextInstruction = context === "desafio" 
      ? "Esta questão é para um DESAFIO CRONOMETRADO. Deve ser inédita e desafiadora, simulando o ambiente real do ENEM."
      : context === "simulado"
      ? "Esta questão é para um SIMULADO COMPLETO. Deve seguir rigorosamente o padrão ENEM com enunciado contextualizado."
      : "Esta questão é para PRÁTICA de exercícios. Foque em consolidar o aprendizado do tema.";

    const systemPrompt = `Você é um especialista em matemática do ENEM. Sua tarefa é criar questões INÉDITAS no estilo ENEM.

REGRAS OBRIGATÓRIAS:
1. A questão DEVE ser original e nunca ter aparecido em provas anteriores
2. O enunciado deve ter contexto do dia a dia brasileiro (compras, trabalho, construção, etc.)
3. SEMPRE 5 alternativas: A, B, C, D, E
4. Apenas UMA alternativa correta
5. Os distratores devem ser plausíveis (erros comuns que alunos cometem)
6. A explicação deve ser didática e passo a passo

${contextInstruction}
${difficultyInstruction}

TEMA: ${topicDescription}`;

    const userPrompt = `Crie uma questão de matemática do ENEM sobre ${topicDescription}.

Retorne EXATAMENTE neste formato JSON (sem markdown):
{
  "statement": "Enunciado completo da questão com contexto",
  "options": [
    {"id": "a", "text": "Alternativa A"},
    {"id": "b", "text": "Alternativa B"},
    {"id": "c", "text": "Alternativa C"},
    {"id": "d", "text": "Alternativa D"},
    {"id": "e", "text": "Alternativa E"}
  ],
  "correctAnswer": "letra_correta",
  "explanation": "Resolução passo a passo detalhada",
  "topic": "${topic}",
  "difficulty": "${difficulty}"
}`;

    console.log("Generating question for topic:", topic, "difficulty:", difficulty, "context:", context);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.8,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Limite de requisições excedido. Tente novamente em alguns instantes." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Créditos de IA esgotados. Adicione mais créditos na sua conta." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("Empty response from AI");
    }

    console.log("AI response received, parsing...");

    // Parse the JSON from the response
    let question;
    try {
      // Try to extract JSON from the response (it might be wrapped in markdown)
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        question = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      console.error("Failed to parse AI response:", content);
      throw new Error("Failed to parse question from AI response");
    }

    // Validate the question structure
    if (!question.statement || !question.options || !question.correctAnswer || !question.explanation) {
      throw new Error("Invalid question structure from AI");
    }

    // Generate a unique ID for the question
    question.id = crypto.randomUUID();

    console.log("Question generated successfully:", question.id);

    return new Response(JSON.stringify(question), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("generate-question error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Erro ao gerar questão" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
